# Exercise 8 Chapter 3 <br>
<h1>Author: Aida Matevosyan <br></h1>
<h1>R Markdown <br></h1>

<h2>8. This question involves the use of simple linear regression on the Auto data set.</h2>


```R
auto = ISLR::Auto
```

# (a) Use the lm() function to perform a simple linear regression with mpg as the response and horsepower as the predictor. Use the summary() function to print the results. Comment on the output. For example:

<h3>i.  Is there a relationship between the predictor and the response.</h3>


```R
auto.lin.fit = lm(mpg ~ horsepower, data = auto)
summary(auto.lin.fit)
```


    
    Call:
    lm(formula = mpg ~ horsepower, data = auto)
    
    Residuals:
         Min       1Q   Median       3Q      Max 
    -13.5710  -3.2592  -0.3435   2.7630  16.9240 
    
    Coefficients:
                 Estimate Std. Error t value Pr(>|t|)    
    (Intercept) 39.935861   0.717499   55.66   <2e-16 ***
    horsepower  -0.157845   0.006446  -24.49   <2e-16 ***
    ---
    Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1
    
    Residual standard error: 4.906 on 390 degrees of freedom
    Multiple R-squared:  0.6059,	Adjusted R-squared:  0.6049 
    F-statistic: 599.7 on 1 and 390 DF,  p-value: < 2.2e-16
    


Equation for ŷ = bX + a <br>
ŷ =39.935861−0.157845X1, where b = -0.157845 and a = 39.935861.



<h3>ii. How strong is the relationship between the predictor and the response?</h3>



```R
Res_Errors <- 4.906

mean_mpg <- mean(mpg)

(Res_Errors / mean_mpg) * 100
```


20.9247508377943


<h3>iii.Is the relationship between the predictor and the response positive or negative.</h3><br>

The relationship between mpg and horsepower is negative. ↑ Horsepower => ↓ MPG 

<h3>iv. What is the predicted mpg associated with a horsepower of 98? What are the associated 95% confidence and prediction intervals?</h3>


```R
predict(auto.lin.fit, data.frame(horsepower = 98), interval = "confidence")
```


<table>
<thead><tr><th scope=col>fit</th><th scope=col>lwr</th><th scope=col>upr</th></tr></thead>
<tbody>
	<tr><td>24.46708</td><td>23.97308</td><td>24.96108</td></tr>
</tbody>
</table>




```R
predict(auto.lin.fit, data.frame(horsepower = 98), interval = "prediction")
```


<table>
<thead><tr><th scope=col>fit</th><th scope=col>lwr</th><th scope=col>upr</th></tr></thead>
<tbody>
	<tr><td>24.46708</td><td>14.8094 </td><td>34.12476</td></tr>
</tbody>
</table>



When the horsepower is equal to 98 then the predicted mpg is equal to 24.46708. The 95% confidence interval for this prediction is (23.97308, 24.96108) and the 95% prediction interval is (14.8094, 34.12467)

# (b) Plot the response and the predictor. Use the abline() function to display the least squares regression line.


```R
hp = auto$horsepower
mpg = auto$mpg

plot(hp, mpg, xlab = "Horsepower", ylab = "Miles per gallon")
abline(auto.lin.fit, lwd = 3, col = "red")
```


    
![png](output_13_0.png)
    


# (c) Use the plot() function to produce diagnostic plots of the least squares regression fit. Comment on any problems you see with the fit.


```R
par(mfrow = c(2, 2))
plot(auto.lin.fit)
```


    
![png](output_15_0.png)
    


In plot 'Residuals vs Fitted' we can state that the shape of the line (U-Shape) indicates that there is no linearity between Residuals and Fitted Values. 
